class ChangeLineItemSKUName < ActiveRecord::Migration[8.0]
  def change
    rename_column :warehouse_line_items, :warehouse_sku_id, :sku_id
  end
end
