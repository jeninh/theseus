class CreateWarehouseOrders < ActiveRecord::Migration[8.0]
  def change
    create_table :warehouse_orders do |t|
      t.string :hc_id
      t.references :warehouse_purpose_code, null: false, foreign_key: true
      t.string :aasm_state
      t.string :recipient_email
      t.references :user, null: false, foreign_key: true
      t.boolean :surprise
      t.string :user_facing_title
      t.string :user_facing_description
      t.text :internal_notes
      t.integer :zenventory_id
      t.references :source_tag, null: false, foreign_key: true

      t.timestamps
    end
    add_index :warehouse_orders, :hc_id
  end
end
