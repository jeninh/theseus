class CreateUSPSPaymentAccounts < ActiveRecord::Migration[8.0]
  def change
    create_table :usps_payment_accounts do |t|
      t.references :usps_mailer_id, null: false, foreign_key: true
      t.integer :account_type
      t.string :account_number
      t.string :permit_number
      t.string :permit_zip

      t.timestamps
    end
  end
end
