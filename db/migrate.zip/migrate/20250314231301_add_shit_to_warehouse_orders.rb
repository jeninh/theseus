class AddShitToWarehouseOrders < ActiveRecord::Migration[8.0]
  def change
    add_column :warehouse_orders, :carrier, :string
    add_column :warehouse_orders, :service, :string
    add_column :warehouse_orders, :tracking_number, :string
    add_column :warehouse_orders, :postage_cost, :decimal
    add_column :warehouse_orders, :weight, :decimal

  end
end
