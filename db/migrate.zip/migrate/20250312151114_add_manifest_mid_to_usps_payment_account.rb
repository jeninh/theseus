class AddManifestMidToUSPSPaymentAccount < ActiveRecord::Migration[8.0]
  def change
    add_column :usps_payment_accounts, :manifest_mid, :string
  end
end
