class CreateWarehouseTemplates < ActiveRecord::Migration[8.0]
  def change
    create_table :warehouse_templates do |t|
      t.references :user, null: false, foreign_key: true
      t.string :name
      t.references :source_tag, null: false, foreign_key: true

      t.timestamps
    end
  end
end
