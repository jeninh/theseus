class AddMoreShitToWarehouseSKU < ActiveRecord::Migration[8.0]
  def change
    add_column :warehouse_skus, :actual_cost_to_hc, :decimal
    add_column :warehouse_skus, :declared_unit_cost_override, :decimal
    rename_column :warehouse_skus, :unit_cost, :declared_unit_cost
  end
end
