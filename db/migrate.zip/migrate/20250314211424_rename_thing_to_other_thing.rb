class RenameThingToOtherThing < ActiveRecord::Migration[8.0]
  def change
    rename_column :warehouse_skus, :declared_unit_cost, :average_po_cost
  end
end
