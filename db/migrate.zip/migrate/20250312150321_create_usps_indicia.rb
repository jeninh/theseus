class CreateUSPSIndicia < ActiveRecord::Migration[8.0]
  def change
    create_table :usps_indicia do |t|
      t.integer :processing_category
      t.float :postage_weight
      t.float :postage_length
      t.float :postage_height
      t.float :postage_thickness
      t.boolean :nonmachinable
      t.string :usps_sku
      t.text :raw_usps_response
      t.decimal :postage
      t.date :mailing_date

      t.timestamps
    end
  end
end
