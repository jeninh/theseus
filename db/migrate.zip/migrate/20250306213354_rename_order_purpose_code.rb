class RenameOrderPurposeCode < ActiveRecord::Migration[8.0]
  def change
    rename_column :warehouse_orders, :warehouse_purpose_code_id, :purpose_code_id
  end
end
