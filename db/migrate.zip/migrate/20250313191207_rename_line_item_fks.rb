class RenameLineItemFks < ActiveRecord::Migration[8.0]
  def change
    rename_column :warehouse_line_items, :warehouse_order_id, :order_id
    rename_column :warehouse_line_items, :warehouse_template_id, :template_id
  end
end
