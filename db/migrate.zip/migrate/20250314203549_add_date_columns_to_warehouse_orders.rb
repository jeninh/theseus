class AddDateColumnsToWarehouseOrders < ActiveRecord::Migration[8.0]
  def change
    add_column :warehouse_orders, :dispatched_at, :datetime
    add_column :warehouse_orders, :mailed_at, :datetime
  end
end
