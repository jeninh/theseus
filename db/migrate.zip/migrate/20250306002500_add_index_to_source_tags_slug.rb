class AddIndexToSourceTagsSlug < ActiveRecord::Migration[8.0]
  def change
  end
end
