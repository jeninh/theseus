class CreateWarehouseLineItems < ActiveRecord::Migration[8.0]
  def change
    create_table :warehouse_line_items do |t|
      t.integer :quantity
      t.references :warehouse_sku, null: false, foreign_key: true

      t.timestamps
    end
  end
end
