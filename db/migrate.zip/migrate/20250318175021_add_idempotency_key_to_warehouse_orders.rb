class AddIdempotencyKeyToWarehouseOrders < ActiveRecord::Migration[8.0]
  def change
    add_column :warehouse_orders, :idempotency_key, :string
    add_index :warehouse_orders, :idempotency_key, unique: true
  end
end
