class AddMoreToWarehouseTemplates < ActiveRecord::Migration[8.0]
  def change
    add_column :warehouse_templates, :public, :boolean
  end
end
