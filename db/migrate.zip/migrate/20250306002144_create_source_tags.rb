class CreateSourceTags < ActiveRecord::Migration[8.0]
  def change
    create_table :source_tags do |t|
      t.string :slug
      t.string :name
      t.string :owner

      t.timestamps
    end
  end
end
