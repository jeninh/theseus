class AddCategoryToWarehouseSKUs < ActiveRecord::Migration[8.0]
  def change
    add_column :warehouse_skus, :category, :integer
  end
end
