class CreateUSPSMailerIds < ActiveRecord::Migration[8.0]
  def change
    create_table :usps_mailer_ids do |t|
      t.string :crid
      t.string :mid

      t.timestamps
    end
  end
end
