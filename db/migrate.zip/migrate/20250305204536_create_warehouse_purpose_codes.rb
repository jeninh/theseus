class CreateWarehousePurposeCodes < ActiveRecord::Migration[8.0]
  def change
    create_table :warehouse_purpose_codes do |t|
      t.string :code
      t.string :description

      t.timestamps
    end
    add_index :warehouse_purpose_codes, :code
  end
end
