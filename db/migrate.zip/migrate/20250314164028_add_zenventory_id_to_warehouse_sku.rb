class AddZenventoryIdToWarehouseSKU < ActiveRecord::Migration[8.0]
  def change
    add_column :warehouse_skus, :zenventory_id, :string
  end
end
