class AddHsCodeAndCountryToSkUs < ActiveRecord::Migration[8.0]
  def change
    add_column :warehouse_skus, :hs_code, :string
    add_column :warehouse_skus, :country_of_origin, :string
  end
end
