class AddPaymentAccountToUSPSIndicia < ActiveRecord::Migration[8.0]
  def change
    add_reference :usps_indicia, :usps_payment_account, null: false, foreign_key: true
  end
end
