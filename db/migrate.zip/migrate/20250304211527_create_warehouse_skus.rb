class CreateWarehouseSKUs < ActiveRecord::Migration[8.0]
  def change
    create_table :warehouse_skus do |t|
      t.string :sku
      t.text :description
      t.decimal :unit_cost
      t.text :customs_description
      t.integer :in_stock
      t.boolean :ai_enabled
      t.boolean :enabled

      t.timestamps
    end
    add_index :warehouse_skus, :sku, unique: true
  end
end
