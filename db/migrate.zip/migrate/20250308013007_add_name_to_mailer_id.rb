class AddNameToMailerId < ActiveRecord::Migration[8.0]
  def change
    add_column :usps_mailer_ids, :name, :string
  end
end
